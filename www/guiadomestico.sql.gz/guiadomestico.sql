-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 05/05/2026 às 14:56
-- Versão do servidor: 8.2.0
-- Versão do PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `guiadomestico`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tautoexec`
--

DROP TABLE IF EXISTS `tautoexec`;
CREATE TABLE IF NOT EXISTS `tautoexec` (
  `chave_autoexec` int NOT NULL AUTO_INCREMENT,
  `descr_autoexec` varchar(128) DEFAULT NULL,
  `tabela_autoexec` varchar(128) DEFAULT NULL,
  `codigo_autoexec` text,
  `caixa_autoexec` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_autoexec`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Despejando dados para a tabela `tautoexec`
--

INSERT INTO `tautoexec` (`chave_autoexec`, `descr_autoexec`, `tabela_autoexec`, `codigo_autoexec`, `caixa_autoexec`) VALUES
(1, 'AUTOEXEC', 'tautoexec', '$chave_autoexec = 0;\r\n$descr_autoexec = \"\";\r\n$tabela_autoexec = \"\";\r\n$codigo_autoexec = \"\";\r\n$caixa_autoexec = 0;\r\n\r\n$chave_autoexec = $_POST[\"chave_autoexec\"];\r\n$descr_autoexec = $_POST[\"descr_autoexec\"];\r\n$tabela_autoexec = $_POST[\"tabela_autoexec\"];\r\n$codigo_autoexec = $_POST[\"codigo_autoexec\"];\r\n$caixa_autoexec = $_POST[\"caixa_autoexec\"];\r\n\r\n$strsql = \"\r\ninsert \r\ninto \r\ntautoexec \r\n(chave_autoexec\r\n,descr_autoexec\r\n,tabela_autoexec\r\n,codigo_autoexec\r\n,caixa_autoexec\r\n) \r\nvalues \r\n(:vchave_autoexec\r\n,:vdescr_autoexec\r\n,:vtabela_autoexec\r\n,:vcodigo_autoexec\r\n,:vcaixa_autoexec\r\n)\";\r\n$qautoexec = $pdo->prepare($strsql);\r\n$qautoexec->bindParam(\":vchave_autoexec\", $chave_autoexec);\r\n$qautoexec->bindParam(\":vdescr_autoexec\", $descr_autoexec);\r\n$qautoexec->bindParam(\":vtabela_autoexec\", $tabela_autoexec);\r\n$qautoexec->bindParam(\":vcodigo_autoexec\", $codigo_autoexec);\r\n$qautoexec->bindParam(\":vcaixa_autoexec\", $caixa_autoexec);\r\n$qtautoexec->execute();\r\n$chave_autoexec = $pdo->lastInsertId();\r\nfecha_diario(\"tautoexec\", \"chave_autoexec\", $chave_autoexec, $abre_diario = array(), $campoexcluidos = array(\"\"));\r\n\r\n$abre_diario = abre_diario(\"tautoexec\", \"chave_autoexec\", $chave_autoexec, $campoexcluidos = array(\"\"));\r\n$strsql = \"\r\nupdate \r\ntautoexec \r\nset \r\nchave_autoexec = :vchave_autoexec\r\n,descr_autoexec = :vdescr_autoexec\r\n,tabela_autoexec = :vtabela_autoexec\r\n,codigo_autoexec = :vcodigo_autoexec\r\n,caixa_autoexec = :vcaixa_autoexec\r\nwhere \r\nchave_autoexec = :vchave_autoexec\r\n\";\r\n$qautoexec = $pdo->prepare($strsql);\r\n$qautoexec->bindParam(\":vchave_autoexec\", $chave_autoexec);\r\n$qautoexec->bindParam(\":vdescr_autoexec\", $descr_autoexec);\r\n$qautoexec->bindParam(\":vtabela_autoexec\", $tabela_autoexec);\r\n$qautoexec->bindParam(\":vcodigo_autoexec\", $codigo_autoexec);\r\n$qautoexec->bindParam(\":vcaixa_autoexec\", $caixa_autoexec);\r\n$qtautoexec->execute();\r\nfecha_diario(\"tautoexec\", \"chave_autoexec\", $chave_autoexec, $abre_diario, $campoexcluidos = array(\"\"));\r\n\r\n$strsql = \"\r\nselect \r\ntautoexec.chave_autoexec\r\n,tautoexec.descr_autoexec\r\n,tautoexec.tabela_autoexec\r\n,tautoexec.codigo_autoexec\r\n,tautoexec.caixa_autoexec\r\nfrom \r\ntautoexec \r\nwhere \r\nchave_autoexec = :vchave_autoexec\r\n\";\r\n$qautoexec = $pdo->prepare($strsql);\r\n$qautoexec->bindParam(\":vchave_autoexec\", $chave_autoexec);\r\n$qtautoexec->execute();\r\n', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tcargo`
--

DROP TABLE IF EXISTS `tcargo`;
CREATE TABLE IF NOT EXISTS `tcargo` (
  `chave_cargo` int NOT NULL AUTO_INCREMENT,
  `esocial_cargo` varchar(10) DEFAULT NULL,
  `descr_cargo` varchar(128) DEFAULT NULL,
  `cbo_cargo` varchar(10) DEFAULT NULL,
  `descrdetalhada_cargo` text NOT NULL,
  `dti_cargo` date DEFAULT NULL,
  `dtf_cargo` date DEFAULT NULL,
  `sit_cargo` varchar(20) NOT NULL DEFAULT 'VIGENTE',
  `caixa_cargo` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_cargo`),
  KEY `esocial_cargo` (`esocial_cargo`),
  KEY `cbo_cargo` (`cbo_cargo`),
  KEY `descr_cargo` (`descr_cargo`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tcargo`
--

INSERT INTO `tcargo` (`chave_cargo`, `esocial_cargo`, `descr_cargo`, `cbo_cargo`, `descrdetalhada_cargo`, `dti_cargo`, `dtf_cargo`, `sit_cargo`, `caixa_cargo`) VALUES
(1, '1', 'Empregado doméstico nos serviços gerais', '5121-05', 'Realiza limpeza, arrumação, lavagem e passagem de roupas, preparo de refeições simples, manutenção de ambientes e apoio geral na residência. ', '1943-05-01', NULL, 'VIGENTE', 1),
(2, '2', 'Empregado doméstico arrumador', '5121-10', 'Organiza quartos, armários e ambientes, arruma roupas e objetos pessoais, mantém ordem e higiene da casa. ', '1943-05-01', NULL, 'VIGENTE', 1),
(3, '3', 'Empregado doméstico faxineiro', '5121-15', 'Executa faxinas completas, higienização profunda de pisos, banheiros, cozinhas e áreas externas. ', '1943-05-01', NULL, 'VIGENTE', 1),
(4, '4', 'Babá', '5162-05', 'Cuida de crianças, acompanha alimentação, higiene, brincadeiras, atividades educativas e segurança. ', '1943-05-01', NULL, 'VIGENTE', 1),
(5, '5', 'Passador de roupas', '5133-05', 'Passa roupas e tecidos, organiza peças, identifica reparos e conserva vestuário. ', '1943-05-01', NULL, 'VIGENTE', 1),
(6, '6', 'Lavadeiro, em geral', '5133-10', 'Lava roupas e tecidos, manuseia máquinas de lavar, separa peças por tipo e tecido. ', '1943-05-01', NULL, 'VIGENTE', 1),
(7, '7', 'Caseiro', '5121-20', 'Zela pela manutenção da casa e áreas externas, cuida de jardins, animais e segurança. ', '1943-05-01', NULL, 'VIGENTE', 1),
(8, '8', 'Governanta de residência', '5131-05', 'Supervisiona serviços domésticos, organiza equipe, controla compras e estoque da casa. ', '1943-05-01', NULL, 'VIGENTE', 1),
(9, '9', 'Mordomo de residência', '5131-10', 'Coordena atendimento, recepção de convidados, serviços de mesa e organização de eventos. ', '1943-05-01', NULL, 'VIGENTE', 1),
(10, '10', 'Cozinheiro do serviço doméstico', '5132-10', 'Prepara refeições, organiza cardápios, cuida da higiene da cozinha e utensílios. ', '1943-05-01', NULL, 'VIGENTE', 1),
(11, '11', 'Cuidador de pessoas idosas e dependentes', '5162-10', 'Auxilia idosos e dependentes em alimentação, higiene, locomoção, medicação e companhia. ', '1943-05-01', NULL, 'VIGENTE', 1),
(12, '12', 'Motorista no serviço doméstico', '7823-10', 'Conduz veículos da residência, transporta moradores, realiza manutenção básica do carro. ', '1943-05-01', NULL, 'VIGENTE', 1),
(13, '13', 'Motorista particular', '7823-15', 'Transporta pessoas e bens em veículos privados, planeja rotas e garante segurança. ', '1943-05-01', NULL, 'VIGENTE', 1),
(14, '14', 'Preparador físico', '2241-05', 'Planeja e acompanha exercícios físicos, avalia condicionamento e orienta treinos personalizados. ', '1943-05-01', NULL, 'VIGENTE', 1),
(15, '15', 'Chefe de cozinha', '5132-05', 'Coordena equipe de cozinha, elabora cardápios, supervisiona preparo e qualidade dos alimentos. ', '1943-05-01', NULL, 'VIGENTE', 1),
(16, '16', 'Subchefe de cozinha', '5132-15', 'Auxilia o chefe de cozinha na coordenação da equipe, supervisiona preparo de pratos, controla estoque e garante qualidade dos alimentos. ', '1943-05-01', NULL, 'VIGENTE', 1),
(17, '17', 'Supervisor de cozinha', '5132-20', 'Supervisiona produção culinária, organiza equipe, controla insumos e assegura padrões de higiene e segurança alimentar. ', '1943-05-01', NULL, 'VIGENTE', 1),
(18, '18', 'Dama de companhia', '5162-25', 'Acompanha pessoas em atividades sociais e pessoais, oferece apoio emocional, organiza compromissos e auxilia em deslocamentos. ', '1943-05-01', NULL, 'VIGENTE', 1),
(19, '19', 'Garçom', '5134-05', 'Atende clientes, serve alimentos e bebidas, organiza mesas, orienta sobre cardápios e garante qualidade no atendimento. ', '1943-05-01', NULL, 'VIGENTE', 1),
(20, '20', 'Jardineiro', '6220-10', 'Cuida de jardins e áreas verdes, realiza plantio, poda, irrigação, adubação e controle de pragas. ', '1943-05-01', NULL, 'VIGENTE', 1),
(21, '21', 'Porteiro', '5174-05', 'Controla entrada e saída de pessoas e veículos, registra visitantes, zela pela segurança e organiza correspondências. ', '1943-05-01', NULL, 'VIGENTE', 1),
(22, '22', 'Vigia', '5174-10', 'Realiza rondas, vigia patrimônio, previne riscos e comunica ocorrências de segurança. ', '1943-05-01', NULL, 'VIGENTE', 1),
(23, '23', 'Secretário, em geral', '2523-05', 'Organiza agendas, documentos e correspondências, atende clientes, prepara relatórios e apoia rotinas administrativas. ', '1943-05-01', NULL, 'VIGENTE', 1),
(24, '24', 'Enfermeiro', '2235-05', 'Planeja e coordena assistência de enfermagem, realiza consultas, supervisiona equipe, promove saúde e previne doenças. ', '1943-05-01', NULL, 'VIGENTE', 1),
(25, '25', 'Atendente de enfermagem no serviço doméstico', '5151-05', 'Auxilia em cuidados básicos de saúde, higiene, administração de medicamentos simples e acompanhamento de pacientes em casa. ', '1943-05-01', NULL, 'VIGENTE', 1),
(26, '26', 'Auxiliar de enfermagem', '3222-05', 'Executa procedimentos simples de enfermagem, coleta material para exames, auxilia em curativos e cuidados básicos. ', '1943-05-01', NULL, 'VIGENTE', 1),
(27, '27', 'Técnico de enfermagem', '3222-10', 'Realiza procedimentos técnicos sob supervisão, administra medicamentos, auxilia em exames e acompanha pacientes. ', '1943-05-01', NULL, 'VIGENTE', 1),
(28, '28', 'Assistente social', '2516-05', 'Apoia indivíduos e famílias em questões sociais, orienta sobre direitos, promove inclusão e articula políticas públicas. ', '1943-05-01', NULL, 'VIGENTE', 1),
(29, '29', 'Fisioterapeutas', '2236-05', 'Avaliam condições físicas, aplicam técnicas de reabilitação, prescrevem exercícios e acompanham evolução de pacientes. ', '1943-05-01', NULL, 'VIGENTE', 1),
(30, '30', 'Médicos, em geral', '2251-05', 'Diagnostica e trata doenças, prescreve terapias, realiza consultas, acompanha evolução clínica e promove saúde preventiva. ', '1943-05-01', NULL, 'VIGENTE', 1),
(31, '31', 'Nutricionistas', '2237-05', 'Planejam dietas e cardápios, avaliam estado nutricional, orientam alimentação saudável, acompanham pacientes em hospitais, clínicas e domicílios. ', '1943-05-01', NULL, 'VIGENTE', 1),
(32, '32', 'Fonoaudiólogos', '2238-05', 'Diagnosticam e tratam distúrbios da fala, linguagem, voz e audição; aplicam terapias e acompanham evolução dos pacientes. ', '1943-05-01', NULL, 'VIGENTE', 1),
(33, '33', 'Psicólogos e psicanalistas', '2510-05', 'Realizam atendimento psicológico, aplicam testes e técnicas terapêuticas, promovem saúde mental e bem-estar emocional. ', '1943-05-01', NULL, 'VIGENTE', 1),
(34, '34', 'Terapeutas ocupacionais e afins', '2263-05', 'Desenvolvem atividades para reabilitação física, cognitiva e social, estimulando autonomia e integração de pessoas com limitações. ', '1943-05-01', NULL, 'VIGENTE', 1),
(35, '35', 'Professores de educação infantil', '2311-05', 'Ministram aulas para crianças pequenas, promovem desenvolvimento cognitivo, motor e social, cuidam da rotina escolar e da integração com famílias. ', '1943-05-01', NULL, 'VIGENTE', 1),
(36, '36', 'Professores de ensino fundamental', '2312-05', 'Lecionam disciplinas básicas, acompanham desempenho escolar, elaboram atividades pedagógicas e promovem inclusão educacional. ', '1943-05-01', NULL, 'VIGENTE', 1),
(37, '37', 'Professores de ensino médio', '2313-05', 'Ministram disciplinas específicas, preparam alunos para vestibulares e mercado de trabalho, desenvolvem projetos pedagógicos. ', '1943-05-01', NULL, 'VIGENTE', 1),
(38, '38', 'Administradores', '2521-05', 'Planejam e gerenciam processos organizacionais, coordenam equipes, elaboram estratégias e controlam recursos financeiros e humanos. ', '1943-05-01', NULL, 'VIGENTE', 1),
(39, '39', 'Contadores e afins', '2524-05', 'Executam escrituração contábil, elaboram balanços, relatórios financeiros, análises de custos e orientam sobre obrigações fiscais. ', '1943-05-01', NULL, 'VIGENTE', 1),
(40, '40', 'Economista doméstico', '2512-05', 'Planeja orçamento familiar, orienta consumo consciente, organiza compras e promove economia doméstica. ', '1943-05-01', NULL, 'VIGENTE', 1),
(41, '41', 'Marinheiro de esporte e recreio', '3411-05', 'Opera embarcações de lazer, realiza manobras, garante segurança dos passageiros e manutenção básica da embarcação. ', '1943-05-01', NULL, 'VIGENTE', 1),
(42, '42', 'Marinheiro de convés', '3411-10', 'Auxilia na navegação, manutenção e operação de embarcações, participa de manobras e segurança a bordo.', '1943-05-01', NULL, 'VIGENTE', 1),
(43, '43', 'Moço de convés', '3411-15', 'Executa tarefas auxiliares em embarcações, como limpeza, manutenção e apoio nas manobras. ', '1943-05-01', NULL, 'VIGENTE', 1),
(44, '44', 'Piloto comercial de helicóptero', '2153-10', 'Pilota helicópteros em voos comerciais, planeja rotas, cumpre normas de tráfego aéreo e garante segurança dos passageiros. ', '1943-05-01', NULL, 'VIGENTE', 1),
(45, '45', 'Piloto de aeronaves', '2153-05', 'Pilota aviões em voos nacionais e internacionais, conduz navegação aérea, coordena tripulação, comunica-se com órgãos de tráfego e assegura segurança operacional. ', '1943-05-01', NULL, 'VIGENTE', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tcfgftp`
--

DROP TABLE IF EXISTS `tcfgftp`;
CREATE TABLE IF NOT EXISTS `tcfgftp` (
  `chave_cfgftp` int NOT NULL AUTO_INCREMENT,
  `descr_cfgftp` varchar(50) DEFAULT NULL,
  `servidor_cfgftp` varchar(128) DEFAULT NULL,
  `usuario_cfgftp` varchar(128) DEFAULT NULL,
  `senha_cfgftp` varchar(50) DEFAULT NULL,
  `extensoesarq_cfgftp` varchar(256) DEFAULT NULL,
  `caixa_cfgftp` varchar(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_cfgftp`),
  KEY `ix_caixa_cfgftp` (`chave_cfgftp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tcliente`
--

DROP TABLE IF EXISTS `tcliente`;
CREATE TABLE IF NOT EXISTS `tcliente` (
  `chave_cliente` int NOT NULL AUTO_INCREMENT,
  `chave_repr` int NOT NULL DEFAULT '0',
  `chave_sitcliente` int DEFAULT NULL,
  `nome_cliente` varchar(128) NOT NULL,
  `fantasia_cliente` varchar(128) DEFAULT NULL,
  `cep_cliente` varchar(10) DEFAULT NULL,
  `codibge_cliente` varchar(10) DEFAULT NULL,
  `end_cliente` varchar(60) DEFAULT NULL,
  `num_cliente` varchar(20) DEFAULT NULL,
  `compl_cliente` varchar(50) DEFAULT NULL,
  `bairro_cliente` varchar(50) DEFAULT NULL,
  `cid_cliente` varchar(50) DEFAULT NULL,
  `uf_cliente` varchar(20) DEFAULT NULL,
  `telarea_cliente` varchar(10) DEFAULT NULL,
  `tel_cliente` varchar(128) DEFAULT NULL,
  `email_cliente` varchar(256) DEFAULT NULL,
  `emailcom_cliente` varchar(256) DEFAULT NULL,
  `emailfin_cliente` varchar(256) DEFAULT NULL,
  `emailfisc_cliente` varchar(256) DEFAULT NULL,
  `cpfcnpj_cliente` varchar(20) DEFAULT NULL,
  `rgie_cliente` varchar(20) DEFAULT NULL,
  `im_cliente` varchar(20) DEFAULT NULL,
  `suframa_cliente` varchar(20) DEFAULT NULL,
  `impsuframa_cliente` varchar(20) DEFAULT NULL,
  `pfpj_cliente` varchar(1) DEFAULT NULL,
  `contribicms_cliente` varchar(10) DEFAULT NULL,
  `regiaovenda_cliente` varchar(50) DEFAULT NULL,
  `tipocli_cliente` varchar(50) DEFAULT NULL,
  `grupo_cliente` varchar(50) DEFAULT NULL,
  `classe_cliente` varchar(20) DEFAULT NULL,
  `ativo_cliente` varchar(1) DEFAULT NULL,
  `motivoinativo_cliente` varchar(50) DEFAULT NULL,
  `situacao_cliente` varchar(50) DEFAULT NULL,
  `situacaocrm_cliente` varchar(50) DEFAULT NULL,
  `dtn_cliente` varchar(12) DEFAULT NULL,
  `dtu_cliente` varchar(12) DEFAULT NULL,
  `percom_cliente` decimal(6,2) NOT NULL DEFAULT '0.00',
  `cod_repr` varchar(50) DEFAULT NULL,
  `nome_repr` varchar(50) DEFAULT NULL,
  `obs_cliente` text,
  `dtc_cliente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sit_cliente` varchar(10) NOT NULL DEFAULT 'ATIVO',
  `origem_cliente` varchar(20) DEFAULT NULL,
  `salesmancode_cliente` varchar(10) DEFAULT NULL,
  `TransactionID_cliente` int DEFAULT NULL,
  `Operation_cliente` varchar(20) DEFAULT NULL,
  `dtaMetrics_cliente` datetime DEFAULT NULL,
  `nomeportal_cliente` varchar(128) DEFAULT NULL,
  `fantasiaportal_cliente` varchar(128) DEFAULT NULL,
  `caixa_cliente` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_cliente`),
  KEY `ix_cod_repr` (`cod_repr`) USING BTREE,
  KEY `ix_caixa_cliente` (`caixa_cliente`) USING BTREE,
  KEY `ix_sit_cliente` (`sit_cliente`) USING BTREE,
  KEY `ix_fantasia_cliente` (`fantasia_cliente`) USING BTREE,
  KEY `ix_nome_cliente` (`nome_cliente`) USING BTREE,
  KEY `ix_chave_repr` (`chave_repr`) USING BTREE,
  KEY `ix_chave_sitcliente` (`chave_sitcliente`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=5628 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tdiario`
--

DROP TABLE IF EXISTS `tdiario`;
CREATE TABLE IF NOT EXISTS `tdiario` (
  `chave_diario` int NOT NULL AUTO_INCREMENT,
  `nometab_diario` varchar(30) NOT NULL,
  `chavetab_diario` varchar(10) NOT NULL,
  `tipo_diario` varchar(12) NOT NULL DEFAULT 'INCLUSAO',
  `usuario_diario` varchar(50) NOT NULL,
  `dta_diario` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `obs_diario` longtext NOT NULL,
  PRIMARY KEY (`chave_diario`),
  KEY `nometab_diario` (`nometab_diario`),
  KEY `chavetab_diario` (`chavetab_diario`)
) ENGINE=MyISAM AUTO_INCREMENT=84889 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tdiario`
--

INSERT INTO `tdiario` (`chave_diario`, `nometab_diario`, `chavetab_diario`, `tipo_diario`, `usuario_diario`, `dta_diario`, `obs_diario`) VALUES
(84813, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-18 17:46:13', '<tipo_usuario>\r\n  <->ADMINISTRADOR</->\r\n  <+></+>\r\n<sit_usuario>\r\n  <->ATIVO</->\r\n  <+></+>'),
(84814, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-18 17:46:17', '<nome_usuario>\r\n  <->Elenir Sousa</->\r\n  <+>Elenir Sousa 3</+>'),
(84815, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-18 17:46:20', '<nome_usuario>\r\n  <->Elenir Sousa 3</->\r\n  <+>Elenir Sousa</+>'),
(84816, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-18 19:54:28', '<tipo_usuario>\r\n  <->ADMINISTRADOR</->\r\n  <+></+>\r\n<sit_usuario>\r\n  <->ATIVO</->\r\n  <+>Ativo</+>'),
(84817, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-18 19:55:08', '<tipo_usuario>\r\n  <-></->\r\n  <+>Usuário</+>'),
(84818, 'tusuario', '175', 'INCLUSAO', 'SITE', '2026-04-19 13:29:02', '<chave_usuario>\r\n  175\r\n<nome_usuario>\r\n  elenir2\r\n<email_usuario>\r\n  elenir@gmail.com\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  USUARIO\r\n<dtc_usuario>\r\n  2026-04-19 10:29:02\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84819, 'tusuario', '176', 'INCLUSAO', 'SITE', '2026-04-19 13:46:40', '<chave_usuario>\r\n  176\r\n<nome_usuario>\r\n  elenir\r\n<email_usuario>\r\n  elenir2@gmail.com\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  USUARIO\r\n<dtc_usuario>\r\n  2026-04-19 10:46:40\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84820, 'tusuario', '175', 'ALTERACAO', 'SITE', '2026-04-20 19:08:10', '<nome_usuario>\r\n  <->elenir2</->\r\n  <+>elenir</+>\r\n<tipo_usuario>\r\n  <->USUARIO</->\r\n  <+>Usuário</+>\r\n<sit_usuario>\r\n  <->ATIVO</->\r\n  <+>Ativo</+>'),
(84821, 'tusuario', '176', 'ALTERACAO', 'SITE', '2026-04-20 19:08:20', '<nome_usuario>\r\n  <->elenir</->\r\n  <+>elenir2</+>\r\n<tipo_usuario>\r\n  <->USUARIO</->\r\n  <+>Usuário</+>\r\n<sit_usuario>\r\n  <->ATIVO</->\r\n  <+>Ativo</+>'),
(84822, 'tusuario', '177', 'INCLUSAO', 'SITE', '2026-04-21 12:06:27', '<chave_usuario>\r\n  177\r\n<nome_usuario>\r\n  Alexandre\r\n<email_usuario>\r\n  alexandre@guiadomestico.com.br\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  ADMINISTRADOR\r\n<dtc_usuario>\r\n  2026-04-21 09:06:27\r\n<sit_usuario>\r\n  Ativo\r\n<caixa_usuario>\r\n  1'),
(84823, 'tusuario', '176', 'ALTERACAO', 'SITE', '2026-04-21 12:08:49', '<tipo_usuario>\r\n  <->Usuário</->\r\n  <+>USUARIO</+>'),
(84824, 'tcargo', '42', 'ALTERACAO', 'SITE', '2026-04-21 12:50:07', '<descrdetalhada_cargo>\r\n  <->Auxilia na navegação, manutenção e operação de embarcações, participa de manobras e segurança a bordo. </->\r\n  <+>Auxilia na navegação, manutenção e operação de embarcações, participa de manobras e segurança a bordo. 2</+>\r\n<sit_cargo>\r\n  <->VIGENTE</->\r\n  <+>Vigente</+>'),
(84825, 'tcargo', '42', 'ALTERACAO', 'SITE', '2026-04-21 12:50:14', '<descrdetalhada_cargo>\r\n  <->Auxilia na navegação, manutenção e operação de embarcações, participa de manobras e segurança a bordo. 2</->\r\n  <+>Auxilia na navegação, manutenção e operação de embarcações, participa de manobras e segurança a bordo.</+>'),
(84826, 'tcargo', '37', 'ALTERACAO', 'SITE', '2026-04-21 14:37:58', '<sit_cargo>\r\n  <->VIGENTE</->\r\n  <+>Vigente</+>'),
(84827, 'tcargo', '41', 'ALTERACAO', 'SITE', '2026-04-21 14:38:03', '<sit_cargo>\r\n  <->VIGENTE</->\r\n  <+>Vigente</+>'),
(84828, 'tcargo', '42', 'ALTERACAO', 'SITE', '2026-04-21 14:42:04', '<sit_cargo>\r\n  <->Vigente</->\r\n  <+>VIGENTE</+>'),
(84829, 'tcargo', '41', 'ALTERACAO', 'SITE', '2026-04-21 14:42:06', '<sit_cargo>\r\n  <->Vigente</->\r\n  <+>VIGENTE</+>'),
(84830, 'tcargo', '37', 'ALTERACAO', 'SITE', '2026-04-21 14:42:09', '<sit_cargo>\r\n  <->Vigente</->\r\n  <+>VIGENTE</+>'),
(84831, 'tusuario', '177', 'ALTERACAO', 'SITE', '2026-04-21 14:43:27', '<sit_usuario>\r\n  <->Ativo</->\r\n  <+>INATIVO</+>'),
(84832, 'tusuario', '177', 'ALTERACAO', 'SITE', '2026-04-21 14:43:32', '<sit_usuario>\r\n  <->INATIVO</->\r\n  <+>ATIVO</+>'),
(84833, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-21 14:43:36', '<sit_usuario>\r\n  <->Ativo</->\r\n  <+>ATIVO</+>'),
(84834, 'tusuario', '176', 'ALTERACAO', 'SITE', '2026-04-21 14:48:21', '<sit_usuario>\r\n  <->Ativo</->\r\n  <+>ATIVO</+>'),
(84835, 'tusuario', '175', 'ALTERACAO', 'SITE', '2026-04-21 14:51:48', '<tipo_usuario>\r\n  <->Usuário</->\r\n  <+>USUARIO</+>\r\n<sit_usuario>\r\n  <->Ativo</->\r\n  <+>ATIVO</+>'),
(84836, 'tusuario', '175', 'ALTERACAO', 'SITE', '2026-04-21 21:22:26', '<nome_usuario>\r\n  <->elenir</->\r\n  <+>Elenir Sousa</+>'),
(84837, 'tusuario', '176', 'ALTERACAO', 'SITE', '2026-04-21 21:22:38', '<nome_usuario>\r\n  <->elenir2</->\r\n  <+>Elenir 007</+>'),
(84838, 'tusuario', '175', 'ALTERACAO', 'SITE', '2026-04-21 21:22:50', '<nome_usuario>\r\n  <->Elenir Sousa</->\r\n  <+>Coiote</+>'),
(84839, 'tusuario', '176', 'ALTERACAO', 'SITE', '2026-04-21 21:23:05', '<nome_usuario>\r\n  <->Elenir 007</->\r\n  <+>Papa Léguas</+>'),
(84840, 'tusuario', '175', 'ALTERACAO', 'SITE', '2026-04-21 21:23:14', '<nome_usuario>\r\n  <->Coiote</->\r\n  <+>Coyote</+>'),
(84841, 'tusuario', '176', 'ALTERACAO', 'SITE', '2026-04-21 21:23:26', '<nome_usuario>\r\n  <->Papa Léguas</->\r\n  <+>Silvester</+>'),
(84842, 'tusuario', '176', 'ALTERACAO', 'SITE', '2026-04-21 21:24:33', '<nome_usuario>\r\n  <->Silvester</->\r\n  <+>Sylvester</+>'),
(84843, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-21 21:29:18', '<nome_usuario>\r\n  <->Elenir Sousa</->\r\n  <+>Tom</+>'),
(84844, 'tusuario', '177', 'ALTERACAO', 'SITE', '2026-04-21 21:29:30', '<nome_usuario>\r\n  <->Alexandre</->\r\n  <+>Jerry</+>'),
(84845, 'tusuario', '178', 'INCLUSAO', 'SITE', '2026-04-21 21:31:16', '<chave_usuario>\r\n  178\r\n<nome_usuario>\r\n  Smurfette\r\n<email_usuario>\r\n  gabrielly@guiadomestico.com.br\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  ADMINISTRADOR\r\n<dtc_usuario>\r\n  2026-04-21 18:31:16\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84846, 'tusuario', '177', 'ALTERACAO', 'SITE', '2026-04-21 21:31:54', '<nome_usuario>\r\n  <->Jerry</->\r\n  <+>Brain</+>'),
(84847, 'tusuario', '179', 'INCLUSAO', 'SITE', '2026-04-21 21:42:02', '<chave_usuario>\r\n  179\r\n<nome_usuario>\r\n  Porky Pig\r\n<email_usuario>\r\n  felipe@guiadomestico.com.br\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  ADMINISTRADOR\r\n<dtc_usuario>\r\n  2026-04-21 18:42:02\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84848, 'tusuario', '180', 'INCLUSAO', 'SITE', '2026-04-21 21:47:54', '<chave_usuario>\r\n  180\r\n<nome_usuario>\r\n  Fred Flintstone\r\n<email_usuario>\r\n  geraldo@guiadomestico.com.br\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  ADMINISTRADOR\r\n<dtc_usuario>\r\n  2026-04-21 18:47:54\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84849, 'tusuario', '181', 'INCLUSAO', 'SITE', '2026-04-21 21:49:00', '<chave_usuario>\r\n  181\r\n<nome_usuario>\r\n  Muttley\r\n<email_usuario>\r\n  leandro@guiadomestico.com.br\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  ADMINISTRADOR\r\n<dtc_usuario>\r\n  2026-04-21 18:49:00\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84850, 'tusuario', '182', 'INCLUSAO', 'SITE', '2026-04-21 21:58:34', '<chave_usuario>\r\n  182\r\n<nome_usuario>\r\n  Daffy Duck\r\n<email_usuario>\r\n  Thierre@guiadomestico.com.br\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  ADMINISTRADOR\r\n<dtc_usuario>\r\n  2026-04-21 18:58:34\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84851, 'tusuario', '183', 'INCLUSAO', 'SITE', '2026-04-21 22:04:14', '<chave_usuario>\r\n  183\r\n<nome_usuario>\r\n  R2D2\r\n<email_usuario>\r\n  andrea@guiadomestico.com.br\r\n<senha_usuario>\r\n  123123\r\n<tipo_usuario>\r\n  ADMINISTRADOR\r\n<dtc_usuario>\r\n  2026-04-21 19:04:14\r\n<sit_usuario>\r\n  ATIVO\r\n<caixa_usuario>\r\n  1'),
(84852, 'tusuario', '183', 'ALTERACAO', 'SITE', '2026-04-21 22:04:41', '<email_usuario>\r\n  <->andrea@guiadomestico.com.br</->\r\n  <+>andre@guiadomestico.com.br</+>'),
(84853, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-27 00:46:30', '<chave_cargo>\r\n  <->0</->\r\n  <+>1</+>\r\n<salario_usuario>\r\n  <->0</->\r\n  <+>99</+>\r\n<dti_usuario>\r\n  <-></->\r\n  <+>2024-10-01</+>\r\n<hrdia_usuario>\r\n  <->0</->\r\n  <+>8</+>\r\n<diasemana_usuario>\r\n  <->0</->\r\n  <+>5</+>'),
(84854, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-27 00:48:56', '<salario_usuario>\r\n  <->99.00</->\r\n  <+>20400.00</+>\r\n<dti_usuario>\r\n  <->2024-10-01</->\r\n  <+>2024-01-01</+>'),
(84855, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-27 00:49:50', '<salario_usuario>\r\n  <->20400.00</->\r\n  <+>2400.00</+>\r\n<dti_usuario>\r\n  <->2024-01-01</->\r\n  <+>2025-01-01</+>'),
(84856, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-27 00:55:35', '<salario_usuario>\r\n  <->2400.00</->\r\n  <+>2400.35</+>\r\n<dti_usuario>\r\n  <->2025-01-01</->\r\n  <+>2023-01-01</+>'),
(84857, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-27 01:07:03', '<dti_usuario>\r\n  <->2023-01-01</->\r\n  <+>2024-03-01</+>'),
(84858, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-04-27 01:17:02', '<salario_usuario>\r\n  <->2400.35</->\r\n  <+>2400.36</+>'),
(84859, 'ttabinss', '1', 'INCLUSAO', 'SITE', '2026-05-01 01:47:55', '<chave_tabinss>\r\n  1\r\n<ano_tabinss>\r\n  2026\r\n<vli_tabinss>\r\n  0.00\r\n<vlf_tabinss>\r\n  1621.00\r\n<aliq_tabinss>\r\n  7.50\r\n<vlded_tabinss>\r\n  0.00\r\n<caixa_tabinss>\r\n  1'),
(84860, 'ttabinss', '2', 'INCLUSAO', 'SITE', '2026-05-01 01:48:34', '<chave_tabinss>\r\n  2\r\n<ano_tabinss>\r\n  2026\r\n<vli_tabinss>\r\n  1621.01\r\n<vlf_tabinss>\r\n  2902.84\r\n<aliq_tabinss>\r\n  9.00\r\n<vlded_tabinss>\r\n  24.32\r\n<caixa_tabinss>\r\n  1'),
(84861, 'ttabinss', '3', 'INCLUSAO', 'SITE', '2026-05-01 01:50:10', '<chave_tabinss>\r\n  3\r\n<ano_tabinss>\r\n  2026\r\n<vli_tabinss>\r\n  2902.85\r\n<vlf_tabinss>\r\n  4354.27\r\n<aliq_tabinss>\r\n  12.00\r\n<vlded_tabinss>\r\n  111.40\r\n<caixa_tabinss>\r\n  1'),
(84862, 'ttabinss', '4', 'INCLUSAO', 'SITE', '2026-05-01 01:51:54', '<chave_tabinss>\r\n  4\r\n<ano_tabinss>\r\n  2026\r\n<vli_tabinss>\r\n  4354.28\r\n<vlf_tabinss>\r\n  8475.55\r\n<aliq_tabinss>\r\n  14.00\r\n<vlded_tabinss>\r\n  198.49\r\n<caixa_tabinss>\r\n  1'),
(84863, 'ttabinss', '5', 'INCLUSAO', 'SITE', '2026-05-01 01:57:06', '<chave_tabinss>\r\n  5\r\n<ano_tabinss>\r\n  2026\r\n<vli_tabinss>\r\n  8475.56\r\n<vlf_tabinss>\r\n  999999999.00\r\n<aliq_tabinss>\r\n  0.00\r\n<vlded_tabinss>\r\n  988.09\r\n<caixa_tabinss>\r\n  1'),
(84864, 'ttabinss', '5', 'ALTERACAO', 'SITE', '2026-05-01 02:20:54', '<aliq_tabinss>\r\n  <->0.00</->\r\n  <+>14.00</+>'),
(84865, 'ttabinss', '5', 'ALTERACAO', 'SITE', '2026-05-01 03:06:32', '<vlf_tabinss>\r\n  <->999999999.00</->\r\n  <+>999999999.99</+>'),
(84866, 'ttabinss', '5', 'ALTERACAO', 'SITE', '2026-05-01 13:31:06', '<vlded_tabinss>\r\n  <->988.09</->\r\n  <+>0.00</+>'),
(84867, 'ttabinss', '5', 'ALTERACAO', 'SITE', '2026-05-01 13:43:11', '<vlfixo_tabinss>\r\n  <->0.00</->\r\n  <+>988.09</+>'),
(84868, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 14:16:36', '<salario_usuario>\r\n  <->2400.36</->\r\n  <+>4500.00</+>'),
(84869, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 14:16:58', '<salario_usuario>\r\n  <->4500.00</->\r\n  <+>240036.00</+>'),
(84870, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 14:17:11', '<salario_usuario>\r\n  <->240036.00</->\r\n  <+>2400.36</+>'),
(84871, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 14:18:32', '<salario_usuario>\r\n  <->2400.36</->\r\n  <+>9000.00</+>'),
(84872, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 14:18:53', '<salario_usuario>\r\n  <->9000.00</->\r\n  <+>20000.00</+>'),
(84873, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 14:19:03', '<salario_usuario>\r\n  <->20000.00</->\r\n  <+>2400.36</+>'),
(84874, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 14:29:53', '<salario_usuario>\r\n  <->2400.36</->\r\n  <+>2400.37</+>'),
(84875, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 18:07:01', '<salario_usuario>\r\n  <->2400.37</->\r\n  <+>15000.00</+>'),
(84876, 'ttabirpf', '1', 'INCLUSAO', 'SITE', '2026-05-01 18:59:46', '<chave_tabirpf>\r\n  1\r\n<ano_tabirpf>\r\n  2026\r\n<vli_tabirpf>\r\n  0.00\r\n<vlf_tabirpf>\r\n  2428.80\r\n<aliq_tabirpf>\r\n  0.00\r\n<vlded_tabirpf>\r\n  0.00\r\n<caixa_tabirpf>\r\n  1'),
(84877, 'ttabirpf', '2', 'INCLUSAO', 'SITE', '2026-05-01 19:02:26', '<chave_tabirpf>\r\n  2\r\n<ano_tabirpf>\r\n  2026\r\n<vli_tabirpf>\r\n  2428.81\r\n<vlf_tabirpf>\r\n  2826.65\r\n<aliq_tabirpf>\r\n  7.50\r\n<vlded_tabirpf>\r\n  182.16\r\n<caixa_tabirpf>\r\n  1'),
(84878, 'ttabirpf', '3', 'INCLUSAO', 'SITE', '2026-05-01 19:03:17', '<chave_tabirpf>\r\n  3\r\n<ano_tabirpf>\r\n  2026\r\n<vli_tabirpf>\r\n  2826.66\r\n<vlf_tabirpf>\r\n  3751.05\r\n<aliq_tabirpf>\r\n  15.00\r\n<vlded_tabirpf>\r\n  394.16\r\n<caixa_tabirpf>\r\n  1'),
(84879, 'ttabirpf', '4', 'INCLUSAO', 'SITE', '2026-05-01 19:04:22', '<chave_tabirpf>\r\n  4\r\n<ano_tabirpf>\r\n  2026\r\n<vli_tabirpf>\r\n  3751.06\r\n<vlf_tabirpf>\r\n  4664.68\r\n<aliq_tabirpf>\r\n  22.50\r\n<vlded_tabirpf>\r\n  675.49\r\n<caixa_tabirpf>\r\n  1'),
(84880, 'ttabirpf', '5', 'INCLUSAO', 'SITE', '2026-05-01 19:05:07', '<chave_tabirpf>\r\n  5\r\n<ano_tabirpf>\r\n  2026\r\n<vli_tabirpf>\r\n  4664.68\r\n<vlf_tabirpf>\r\n  999999999.99\r\n<aliq_tabirpf>\r\n  27.50\r\n<vlded_tabirpf>\r\n  908.75\r\n<caixa_tabirpf>\r\n  1'),
(84881, 'ttabirpf', '5', 'ALTERACAO', 'SITE', '2026-05-01 19:06:28', '<vli_tabirpf>\r\n  <->4664.68</->\r\n  <+>4664.69</+>'),
(84882, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 20:27:43', '<hrdiasab_usuario>\r\n  <->4.00</->\r\n  <+>0.00</+>'),
(84883, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-01 20:35:09', '<salario_usuario>\r\n  <->15000.00</->\r\n  <+>2400.00</+>'),
(84884, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-02 17:45:13', '<salario_usuario>\r\n  <->2400.00</->\r\n  <+>14997.37</+>'),
(84885, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-03 19:15:57', '<nome_usuario>\r\n  <->Tom</->\r\n  <+>Tom cat</+>'),
(84886, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-03 19:16:17', '<email_usuario>\r\n  <->elenircombr@gmail.com</->\r\n  <+></+>'),
(84887, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-03 19:16:28', '<email_usuario>\r\n  <-></->\r\n  <+>elenircombr@gmail.com</+>'),
(84888, 'tusuario', '1', 'ALTERACAO', 'SITE', '2026-05-03 19:20:56', '<nome_usuario>\r\n  <->Tom cat</->\r\n  <+>Tom</+>');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tfollowup`
--

DROP TABLE IF EXISTS `tfollowup`;
CREATE TABLE IF NOT EXISTS `tfollowup` (
  `chave_followup` int NOT NULL AUTO_INCREMENT,
  `chave_terapeuta` int DEFAULT NULL,
  `chave_cliente` int DEFAULT NULL,
  `chave_usuario` int DEFAULT NULL,
  `chave_atendimento` int DEFAULT NULL,
  `descr_followup` varchar(50) NOT NULL,
  `obs_followup` text,
  `dtc_followup` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sit_followup` varchar(50) NOT NULL DEFAULT 'CONCLUIDO',
  `caixa_followup` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_followup`),
  KEY `chave_terapeuta` (`chave_terapeuta`),
  KEY `chave_usuario` (`chave_usuario`),
  KEY `caixa_followup` (`caixa_followup`) USING BTREE,
  KEY `chave_cliente` (`chave_cliente`),
  KEY `chave_atendimento` (`chave_atendimento`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tftp`
--

DROP TABLE IF EXISTS `tftp`;
CREATE TABLE IF NOT EXISTS `tftp` (
  `chave_ftp` int NOT NULL AUTO_INCREMENT,
  `host_ftp` varchar(128) DEFAULT NULL,
  `conta_ftp` varchar(128) DEFAULT NULL,
  `senha_ftp` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`chave_ftp`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tftp`
--

INSERT INTO `tftp` (`chave_ftp`, `host_ftp`, `conta_ftp`, `senha_ftp`) VALUES
(1, 'ftp.guiadomestico.com.br', 'guiadomestico', 'app906508');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tid`
--

DROP TABLE IF EXISTS `tid`;
CREATE TABLE IF NOT EXISTS `tid` (
  `chave_id` int NOT NULL AUTO_INCREMENT,
  `nome_id` varchar(50) NOT NULL,
  `fantasia_id` varchar(50) DEFAULT NULL,
  `tel1_id` varchar(50) DEFAULT NULL,
  `slogan_id` varchar(128) DEFAULT NULL,
  `logo_id` varchar(128) DEFAULT NULL,
  `logocab_id` varchar(128) DEFAULT NULL,
  `logorod_id` varchar(128) DEFAULT NULL,
  `pagarme1_id` varchar(128) DEFAULT NULL,
  `pagarme2_id` varchar(128) DEFAULT NULL,
  `idrecebedor_id` varchar(50) DEFAULT NULL,
  `idrecebedor2_id` varchar(50) DEFAULT NULL,
  `pixkey_id` int DEFAULT '0',
  `caixa_id` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tid`
--

INSERT INTO `tid` (`chave_id`, `nome_id`, `fantasia_id`, `tel1_id`, `slogan_id`, `logo_id`, `logocab_id`, `logorod_id`, `pagarme1_id`, `pagarme2_id`, `idrecebedor_id`, `idrecebedor2_id`, `pixkey_id`, `caixa_id`) VALUES
(1, 'HELP4U', 'HELP4U Emotion', '(11) 9-9187-1061', 'Seu guia de direitos', '', '', '', '', '', 're_ckm5c3io808in0h9t9nhtlfyq', 're_ckmutj95b0eq80h9t49twwumk', NULL, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `trepr`
--

DROP TABLE IF EXISTS `trepr`;
CREATE TABLE IF NOT EXISTS `trepr` (
  `chave_repr` int NOT NULL AUTO_INCREMENT,
  `chave_sitrepr` int DEFAULT NULL,
  `cod_repr` varchar(50) DEFAULT NULL,
  `nome_repr` varchar(50) NOT NULL,
  `fantasia_repr` varchar(50) DEFAULT NULL,
  `end_repr` varchar(50) DEFAULT NULL,
  `num_repr` varchar(50) DEFAULT NULL,
  `compl_repr` varchar(50) DEFAULT NULL,
  `bairro_repr` varchar(50) DEFAULT NULL,
  `cid_repr` varchar(50) DEFAULT NULL,
  `uf_repr` varchar(2) DEFAULT NULL,
  `regiaoatend_repr` varchar(50) DEFAULT NULL,
  `cep_repr` varchar(10) DEFAULT NULL,
  `codibge_repr` varchar(10) DEFAULT NULL,
  `telarea_repr` varchar(10) DEFAULT NULL,
  `tel_repr` varchar(128) DEFAULT NULL,
  `email_repr` varchar(256) DEFAULT NULL,
  `cpfcnpj_repr` varchar(20) DEFAULT NULL,
  `rgie_repr` varchar(20) DEFAULT NULL,
  `dtc_repr` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sit_repr` varchar(10) DEFAULT 'ATIVO',
  `caixa_repr` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_repr`),
  KEY `ix_cod_repr` (`cod_repr`) USING BTREE,
  KEY `ix_caixa_repr` (`caixa_repr`) USING BTREE,
  KEY `ix_chave_sitrepr` (`chave_sitrepr`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tsitcliente`
--

DROP TABLE IF EXISTS `tsitcliente`;
CREATE TABLE IF NOT EXISTS `tsitcliente` (
  `chave_sitcliente` int NOT NULL AUTO_INCREMENT,
  `descr_sitcliente` varchar(50) NOT NULL,
  `dtc_sitcliente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `caixa_sitcliente` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_sitcliente`),
  KEY `ix_caixa_sitcliente` (`caixa_sitcliente`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tsitcliente`
--

INSERT INTO `tsitcliente` (`chave_sitcliente`, `descr_sitcliente`, `dtc_sitcliente`, `caixa_sitcliente`) VALUES
(1, 'Ativo', '2023-03-28 17:04:12', 1),
(2, 'Inativo', '2023-03-28 19:05:45', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tsmtp`
--

DROP TABLE IF EXISTS `tsmtp`;
CREATE TABLE IF NOT EXISTS `tsmtp` (
  `chave_smtp` int NOT NULL AUTO_INCREMENT,
  `host_smtp` varchar(128) DEFAULT NULL,
  `porta_smtp` varchar(10) DEFAULT NULL,
  `conta_smtp` varchar(128) DEFAULT NULL,
  `senha_smtp` varchar(50) DEFAULT NULL,
  `fromname_smtp` varchar(50) DEFAULT NULL,
  `fromemail_smtp` varchar(128) DEFAULT NULL,
  `replyto_smtp` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`chave_smtp`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ttabinss`
--

DROP TABLE IF EXISTS `ttabinss`;
CREATE TABLE IF NOT EXISTS `ttabinss` (
  `chave_tabinss` int NOT NULL AUTO_INCREMENT,
  `ano_tabinss` varchar(4) NOT NULL DEFAULT '''''',
  `vli_tabinss` decimal(12,2) NOT NULL DEFAULT '0.00',
  `vlf_tabinss` decimal(12,2) NOT NULL DEFAULT '0.00',
  `aliq_tabinss` decimal(12,2) NOT NULL DEFAULT '0.00',
  `vlded_tabinss` decimal(12,2) NOT NULL DEFAULT '0.00',
  `vlfixo_tabinss` decimal(12,2) NOT NULL DEFAULT '0.00',
  `caixa_tabinss` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_tabinss`),
  KEY `caixa_tabinss` (`caixa_tabinss`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `ttabinss`
--

INSERT INTO `ttabinss` (`chave_tabinss`, `ano_tabinss`, `vli_tabinss`, `vlf_tabinss`, `aliq_tabinss`, `vlded_tabinss`, `vlfixo_tabinss`, `caixa_tabinss`) VALUES
(1, '2026', 0.00, 1621.00, 7.50, 0.00, 0.00, 1),
(2, '2026', 1621.01, 2902.84, 9.00, 24.32, 0.00, 1),
(3, '2026', 2902.85, 4354.27, 12.00, 111.40, 0.00, 1),
(4, '2026', 4354.28, 8475.55, 14.00, 198.49, 0.00, 1),
(5, '2026', 8475.56, 999999999.99, 14.00, 0.00, 988.09, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `ttabirpf`
--

DROP TABLE IF EXISTS `ttabirpf`;
CREATE TABLE IF NOT EXISTS `ttabirpf` (
  `chave_tabirpf` int NOT NULL AUTO_INCREMENT,
  `ano_tabirpf` varchar(4) NOT NULL DEFAULT '''''',
  `vli_tabirpf` decimal(12,2) NOT NULL DEFAULT '0.00',
  `vlf_tabirpf` decimal(12,2) NOT NULL DEFAULT '0.00',
  `aliq_tabirpf` decimal(12,2) NOT NULL DEFAULT '0.00',
  `vlded_tabirpf` decimal(12,2) NOT NULL DEFAULT '0.00',
  `caixa_tabirpf` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_tabirpf`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `ttabirpf`
--

INSERT INTO `ttabirpf` (`chave_tabirpf`, `ano_tabirpf`, `vli_tabirpf`, `vlf_tabirpf`, `aliq_tabirpf`, `vlded_tabirpf`, `caixa_tabirpf`) VALUES
(1, '2026', 0.00, 2428.80, 0.00, 0.00, 1),
(2, '2026', 2428.81, 2826.65, 7.50, 182.16, 1),
(3, '2026', 2826.66, 3751.05, 15.00, 394.16, 1),
(4, '2026', 3751.06, 4664.68, 22.50, 675.49, 1),
(5, '2026', 4664.69, 999999999.99, 27.50, 908.75, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `ttemplateemail`
--

DROP TABLE IF EXISTS `ttemplateemail`;
CREATE TABLE IF NOT EXISTS `ttemplateemail` (
  `chave_templateemail` int NOT NULL AUTO_INCREMENT,
  `cod_templateemail` varchar(50) NOT NULL,
  `corpo_templateemail` text NOT NULL,
  `caixa_templateemail` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_templateemail`),
  KEY `cod_templateemail` (`cod_templateemail`),
  KEY `caixa_templateemail` (`caixa_templateemail`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tuf`
--

DROP TABLE IF EXISTS `tuf`;
CREATE TABLE IF NOT EXISTS `tuf` (
  `chave_uf` int NOT NULL AUTO_INCREMENT,
  `sigla_uf` varchar(2) DEFAULT NULL,
  `descr_uf` varchar(50) DEFAULT NULL,
  `aliqext_uf` decimal(6,2) NOT NULL DEFAULT '0.00',
  `aliqint_uf` decimal(6,2) NOT NULL DEFAULT '0.00',
  `aliqfcp_uf` decimal(6,2) NOT NULL DEFAULT '0.00',
  `aliqdif_uf` decimal(6,2) NOT NULL DEFAULT '0.00',
  `sit_uf` varchar(20) NOT NULL DEFAULT 'ATIVO',
  `caixa_uf` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_uf`),
  KEY `ix_sigla_uf` (`sigla_uf`) USING BTREE,
  KEY `ix_caixa_uf` (`caixa_uf`) USING BTREE,
  KEY `ix_sit_uf` (`sit_uf`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tuf`
--

INSERT INTO `tuf` (`chave_uf`, `sigla_uf`, `descr_uf`, `aliqext_uf`, `aliqint_uf`, `aliqfcp_uf`, `aliqdif_uf`, `sit_uf`, `caixa_uf`) VALUES
(1, 'AC', 'Acre', 7.00, 17.00, 0.00, 10.00, 'ATIVO', 1),
(2, 'AL', 'Alagoas', 7.00, 17.00, 1.00, 11.00, 'ATIVO', 1),
(3, 'AP', 'Amapá', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(4, 'AM', 'Amazonas', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(5, 'BA', 'Bahia', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(6, 'CE', 'Ceará', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(7, 'DF', 'Distrito Federal', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(8, 'ES', 'Espírito Santo', 7.00, 17.00, 0.00, 10.00, 'ATIVO', 1),
(9, 'GO', 'Goiás', 7.00, 17.00, 0.00, 10.00, 'ATIVO', 1),
(10, 'MA', 'Maranhão', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(11, 'MT', 'Mato Grosso', 7.00, 17.00, 0.00, 10.00, 'ATIVO', 1),
(12, 'MS', 'Mato Grosso do Sul', 7.00, 17.00, 0.00, 10.00, 'ATIVO', 1),
(13, 'MG', 'Minas Gerais', 12.00, 18.00, 0.00, 6.00, 'ATIVO', 1),
(14, 'PA', 'Pará', 7.00, 17.00, 0.00, 10.00, 'ATIVO', 1),
(15, 'PB', 'Paraíba', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(16, 'PR', 'Paraná', 12.00, 18.00, 0.00, 6.00, 'ATIVO', 1),
(17, 'PE', 'Pernambuco', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(18, 'PI', 'Piauí', 7.00, 17.00, 1.00, 11.00, 'ATIVO', 1),
(19, 'RJ', 'Rio de Janeiro', 12.00, 18.00, 2.00, 8.00, 'ATIVO', 1),
(20, 'RN', 'Rio Grande do Norte', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(21, 'RS', 'Rio Grande do Sul', 12.00, 17.00, 0.00, 5.00, 'ATIVO', 1),
(22, 'RO', 'Rondônia', 7.00, 17.50, 0.00, 10.50, 'ATIVO', 1),
(23, 'RR', 'Roraima', 7.00, 17.00, 0.00, 10.00, 'ATIVO', 1),
(24, 'SC', 'Santa Catarina', 12.00, 17.00, 0.00, 5.00, 'ATIVO', 1),
(25, 'SP', 'São Paulo', 0.00, 18.00, 0.00, 0.00, 'ATIVO', 1),
(26, 'SE', 'Sergipe', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1),
(27, 'TO', 'Tocantins', 7.00, 18.00, 0.00, 11.00, 'ATIVO', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tusuario`
--

DROP TABLE IF EXISTS `tusuario`;
CREATE TABLE IF NOT EXISTS `tusuario` (
  `chave_usuario` int NOT NULL AUTO_INCREMENT,
  `chave_cargo` int NOT NULL DEFAULT '0',
  `nome_usuario` varchar(50) NOT NULL,
  `email_usuario` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `senha_usuario` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `tipo_usuario` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'USUARIO',
  `dtc_usuario` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sit_usuario` varchar(20) NOT NULL DEFAULT 'ATIVO',
  `salario_usuario` decimal(12,2) NOT NULL DEFAULT '0.00',
  `dti_usuario` date DEFAULT NULL,
  `hrdia_usuario` decimal(5,2) NOT NULL DEFAULT '8.00',
  `hrdiasab_usuario` decimal(5,2) NOT NULL DEFAULT '4.00',
  `diasemana_usuario` int NOT NULL DEFAULT '0',
  `caixa_usuario` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_usuario`),
  KEY `ix_caixa_usuario` (`caixa_usuario`),
  KEY `ix_ativo_usuario` (`sit_usuario`) USING BTREE,
  KEY `chave_cargo` (`chave_cargo`)
) ENGINE=MyISAM AUTO_INCREMENT=184 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tusuario`
--

INSERT INTO `tusuario` (`chave_usuario`, `chave_cargo`, `nome_usuario`, `email_usuario`, `senha_usuario`, `tipo_usuario`, `dtc_usuario`, `sit_usuario`, `salario_usuario`, `dti_usuario`, `hrdia_usuario`, `hrdiasab_usuario`, `diasemana_usuario`, `caixa_usuario`) VALUES
(1, 1, 'Tom', 'elenircombr@gmail.com', '12345', 'ADMINISTRADOR', '2026-04-14 23:13:46', 'ATIVO', 14997.37, '2024-03-01', 8.00, 0.00, 5, 1),
(175, 0, 'Coyote', 'elenir@gmail.com', '123123', 'USUARIO', '2026-04-19 10:29:02', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(176, 0, 'Sylvester', 'elenir2@gmail.com', '123123', 'USUARIO', '2026-04-19 10:46:40', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(178, 0, 'Smurfette', 'gabrielly@guiadomestico.com.br', '123123', 'ADMINISTRADOR', '2026-04-21 18:31:16', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(177, 0, 'Brain', 'alexandre@guiadomestico.com.br', '123123', 'ADMINISTRADOR', '2026-04-21 09:06:27', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(179, 0, 'Porky Pig', 'felipe@guiadomestico.com.br', '123123', 'ADMINISTRADOR', '2026-04-21 18:42:02', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(180, 0, 'Fred Flintstone', 'geraldo@guiadomestico.com.br', '123123', 'ADMINISTRADOR', '2026-04-21 18:47:54', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(181, 0, 'Muttley', 'leandro@guiadomestico.com.br', '123123', 'ADMINISTRADOR', '2026-04-21 18:49:00', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(182, 0, 'Daffy Duck', 'Thierre@guiadomestico.com.br', '123123', 'ADMINISTRADOR', '2026-04-21 18:58:34', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1),
(183, 0, 'R2D2', 'andre@guiadomestico.com.br', '123123', 'ADMINISTRADOR', '2026-04-21 19:04:14', 'ATIVO', 0.00, NULL, 0.00, 4.00, 0, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tusuarioacesso`
--

DROP TABLE IF EXISTS `tusuarioacesso`;
CREATE TABLE IF NOT EXISTS `tusuarioacesso` (
  `chave_usuarioacesso` int NOT NULL AUTO_INCREMENT,
  `chave_usuario` int NOT NULL,
  `ip_usuarioacesso` varchar(40) DEFAULT NULL,
  `acao_usuarioacesso` varchar(10) NOT NULL DEFAULT 'LOGIN',
  `dta_usuarioacesso` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`chave_usuarioacesso`),
  KEY `ix_chave_usuario` (`chave_usuario`) USING BTREE,
  KEY `ix_dta_usuarioacesso` (`dta_usuarioacesso`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=800 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tusuariolog`
--

DROP TABLE IF EXISTS `tusuariolog`;
CREATE TABLE IF NOT EXISTS `tusuariolog` (
  `chave_usuariolog` int NOT NULL AUTO_INCREMENT,
  `dta_usuariolog` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `caixa_usuariolog` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_usuariolog`),
  KEY `ix_caixa_usuariolog` (`caixa_usuariolog`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tusuariologin`
--

DROP TABLE IF EXISTS `tusuariologin`;
CREATE TABLE IF NOT EXISTS `tusuariologin` (
  `chave_usuariologin` int NOT NULL AUTO_INCREMENT,
  `chave_usuario` int NOT NULL,
  `nome_usuariologin` varchar(50) NOT NULL,
  `login_usuariologin` varchar(50) NOT NULL,
  `senha_usuariologin` varchar(20) NOT NULL,
  `ativo_usuariologin` int NOT NULL DEFAULT '1',
  `caixa_usuariologin` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_usuariologin`),
  KEY `ix_chave_usuario` (`chave_usuario`) USING BTREE,
  KEY `ix_caixa_usuariologin` (`caixa_usuariologin`) USING BTREE,
  KEY `ix_ativo_usuariologin` (`ativo_usuariologin`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tvar`
--

DROP TABLE IF EXISTS `tvar`;
CREATE TABLE IF NOT EXISTS `tvar` (
  `chave_var` int NOT NULL AUTO_INCREMENT,
  `ftpservidor_var` varchar(128) DEFAULT NULL,
  `ftpusuario_var` varchar(50) DEFAULT NULL,
  `ftpsenha_var` varchar(50) DEFAULT NULL,
  `msgerropadrao_var` text,
  `caixa_var` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`chave_var`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Despejando dados para a tabela `tvar`
--

INSERT INTO `tvar` (`chave_var`, `ftpservidor_var`, `ftpusuario_var`, `ftpsenha_var`, `msgerropadrao_var`, `caixa_var`) VALUES
(1, 'guiadomestico.com.br', 'revendaredoma', '?fLL2*7Tleet6dfv', '', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
